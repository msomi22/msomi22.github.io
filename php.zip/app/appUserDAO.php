<?php 
interface appuserDAO{

	 function getUser($username,$password);

	 function putUser($username,$password);

}

?>