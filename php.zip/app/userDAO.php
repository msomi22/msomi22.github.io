<?php 
include("appUserDAO.php");
include("genericDAO.php");

  class userDAO implements appuserDAO{

  	 function getUser($username,$password)
  	{
  		$encrypass = md5($password);
  		$user = "SELECT * FROM user WHERE username = '$username' AND password = '$password' "; 
  		if(!mysql_query($user)){ 
           return "Error:" . mysql_error();
  		}else{
  			header("Location: home.php"); 
  		}
  		
  	}

  	 function putUser($username,$password)
  	{
  		
  	}

  }

 ?>