<?php 
$con = mysql_connect("localhost","root","peter"); 
if(!$con){
	echo "Error:" .mysql_error(); 
}

msql_select_db("obeddb",$con); 

 ?>