<!DOCTYPE html>
<html>
<head>
	<title>login page</title>
	<link rel="stylesheet" type="text/css" href="site.css">
</head>
<body>
<h1 align="center">Login page</h1>

<form method="POST" action="loginControl.php">
	<fieldset>
	<div id="login">
		<div id="input">
			username:<input type="text" name="username" value="">
		</div>
		<div id="input">
			password:<input type="password" name="password" value="">
		</div>
		<div id="submit"> 
			<input type="submit" name="login" value="login">
		</div>
	</div>
	
	</fieldset>
</form>


</body>
</html>