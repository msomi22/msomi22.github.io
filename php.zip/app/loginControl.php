<?php  
include("userDAO.php");

class loginContoller extends userDAO{

$username = validate($_POST['username']);
$password = validate($_POST['password']);

function validate($data){
	$data = trim($data);
	$data = htmlspecialchars($data);
	$data = stripcslashes($data);
  return $data;
}

echo " username " . $username .' password '. $password;

if(isset($_POST["login"])){
  userDAO::getUser($username,$password); 
}else{
	header("Location: index.php");
}

}

?>